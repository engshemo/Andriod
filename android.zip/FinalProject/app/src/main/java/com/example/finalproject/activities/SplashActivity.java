package com.example.finalproject.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.example.finalproject.R;

public class SplashActivity extends AppCompatActivity {
    TextView splash_tv;
    ImageView splash_image;
    CardView splash_gv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        this.setTitle("Welcome Page .");
        splash_tv=findViewById(R.id.splash_tv);
        splash_gv=findViewById(R.id.splash_gv);
        YoYo.with(Techniques.BounceInRight)
                .duration(700)
                .repeat(5)
                .playOn(findViewById(R.id.splash_tv));
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
                finish();
            }
        }, 3000);
    }
}