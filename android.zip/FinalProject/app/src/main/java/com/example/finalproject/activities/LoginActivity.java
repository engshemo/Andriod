package com.example.finalproject.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.finalproject.R;
import com.example.finalproject.fragments.DialogFragment;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    EditText et_username,et_num;
    Spinner spinner;
    TextView tv_spinner;
    Button btu_login;
    SharedPreferences sp;
    SharedPreferences.Editor edit;
    public final String USERNAME_KEY="username";
    public  String NUMBER_KEY="Table";
    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        this.setTitle("Login Page .");
        spinner = findViewById(R.id.spinner);
        tv_spinner = findViewById(R.id.tv_spinner);
        spinner.setOnItemSelectedListener(this);
        ArrayList<String> items = new ArrayList<>();
        items.add("Table 1");
        items.add("Table 2");
        items.add("Table 3");
        items.add("Table 4");
        ArrayAdapter arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);
//      arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);
        et_username = findViewById(R.id.et_sp_username);
        btu_login = findViewById(R.id.btu_sp_login);
        sp = getSharedPreferences("shimaa", MODE_PRIVATE);
        edit = sp.edit();
        String username = sp.getString(USERNAME_KEY, "no username");
        String num = sp.getString(NUMBER_KEY, "no num");

        if (username != ""  && num != "") {

            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }

        btu_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user1 = et_username.getText().toString();
               // String num1 = et_num.getText().toString();
                String num1 =NUMBER_KEY;
                SharedPreferences.Editor edit =sp.edit();
                edit.putString(USERNAME_KEY,user1);//key and string name
                edit.putString(NUMBER_KEY,num1);//key and string name
                edit.apply();
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
       NUMBER_KEY = parent.getItemAtPosition(position).toString();
        // Showing selected spinner item
     //   Toast.makeText(getApplicationContext(), "Selected: " + NUMBER_KEY, Toast.LENGTH_LONG).show();

    }

    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
        Toast.makeText(getApplicationContext(), "Please Selecting ", Toast.LENGTH_LONG).show();


    }

}