package com.example.finalproject.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.example.finalproject.R;
import com.example.finalproject.models.Drinks;

import java.util.ArrayList;

public class DrinkAdapter extends BaseAdapter {
    ArrayList<Drinks> drinks;
    Context context;
    LayoutInflater layoutInflater;

    public DrinkAdapter(ArrayList<Drinks> drinks, Context context) {
        this.drinks = drinks;
        this.context = context;
        layoutInflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return drinks.size();
    }

    @Override
    public Object getItem(int position) {
        return drinks.get(position);
    }

    @Override
    public long getItemId(int position) {
        return drinks.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View root = layoutInflater.inflate(R.layout.drink_item,null);
        ImageView drink_image =root.findViewById(R.id.drink_image);
        TextView drink_name =root.findViewById(R.id.drink_name);
        TextView drink_price =root.findViewById(R.id.drink_price);
        ConstraintLayout drink_layout =root.findViewById(R.id.drink_layout);
        drink_image.setImageResource(drinks.get(position).getImage());
        drink_name.setText(drinks.get(position).getName());
        drink_price.setText(drinks.get(position).getPrice());
//        drink_layout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                YoYo.with(Techniques.Tada)
//                        .duration(700)
//                        .repeat(5)
//                        .playOn(root.findViewById(R.id.drink_layout));
//            }
//        });
        return root;
    }
}
