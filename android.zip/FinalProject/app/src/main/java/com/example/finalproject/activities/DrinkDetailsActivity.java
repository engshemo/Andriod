package com.example.finalproject.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.example.finalproject.R;
import com.example.finalproject.fragments.DialogFragment;

import de.hdodenhof.circleimageview.CircleImageView;

public class DrinkDetailsActivity extends AppCompatActivity {
    CircleImageView iv_drink_image;
    Button btu_drink_select;
    TextView tv_drink_name,tv_drink_price,tv_drink_desc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink_details);
        this.setTitle("Drink Details Page .");

        iv_drink_image = findViewById(R.id.iv_drink_image);
        tv_drink_desc = findViewById(R.id.tv_drink_desc);
        tv_drink_name = findViewById(R.id.tv_drink_name);
        tv_drink_price = findViewById(R.id.tv_drink_price);
        btu_drink_select = findViewById(R.id.btu_drink_select);
        Intent intent = getIntent();
        int drink_iv = intent.getIntExtra("drink_iv", 1);
        String drink_name = intent.getStringExtra("drink_name");
        String drink_price = intent.getStringExtra("drink_price");
        String drink_dec = intent.getStringExtra("drink_dec");
        btu_drink_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment fragment = DialogFragment.newInstance("Attention", " Do you really want this drink ? ", R.drawable.ic_alert);
                fragment.show(getSupportFragmentManager(), null);
            }
        });
        YoYo.with(Techniques.BounceInRight)
                .duration(700)
                .repeat(3)
                .playOn(findViewById(R.id.iv_drink_image));
        YoYo.with(Techniques.BounceInRight)
                .duration(700)
                .repeat(2)
                .playOn(findViewById(R.id.tv_drink_desc));
        YoYo.with(Techniques.BounceInRight)
                .duration(700)
                .repeat(2)
                .playOn(findViewById(R.id.tv_drink_name));
        YoYo.with(Techniques.BounceInRight)
                .duration(700)
                .repeat(2)
                .playOn(findViewById(R.id.tv_drink_price));

        if (drink_iv != 0) {
            iv_drink_image.setImageResource(drink_iv);
        }
        if (drink_dec != null) {
            tv_drink_desc.setText(drink_dec);
        }
        if (drink_price != null) {
            tv_drink_price.setText(drink_price);
        }
        if (drink_name != null) {
            tv_drink_name.setText(drink_name);
        }

    }
}