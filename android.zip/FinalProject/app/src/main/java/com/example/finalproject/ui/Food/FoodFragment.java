package com.example.finalproject.ui.Food;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.R;
import com.example.finalproject.activities.FoodDetialsActivity;
import com.example.finalproject.adapters.DessertAdapter;
import com.example.finalproject.adapters.FoodAdapter;
import com.example.finalproject.models.Foods;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

public class FoodFragment extends Fragment {
    ListView lv_foods;
    ArrayList<Foods> foods;
    private HomeViewModel homeViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_food, container, false);
        lv_foods=root.findViewById(R.id.lv_foods);
        foods = new ArrayList<>();
        foods.add(new Foods(1,R.drawable.pizzahut,"Pizza Hut ","55 $","Pizza is a dish that has its origins in eastern Mediterranean countries such as Greece and Turkey, where they cooked a layer of dough on a hot stone and covered it with various types of ingredients such as meat and vegetables, then the Italian soldiers took it from them to transport it to Italy with the addition of tomato sauce and mozzarella cheese, then transport it Italian immigrants to America."));
        foods.add(new Foods(2,R.drawable.burgers,"Hamburger","20 $","Hamburger is an American food that is often considered a fast food and has spread rapidly all over the world until it became a globalization meal, consisting of a sandwich of meat or chicken in addition to ketchup, mayonnaise and vegetables, and eaten with it french fries and soft drinks such as Pepsi and Coca-Cola."));
        foods.add(new Foods(3,R.drawable.fish,"Fish"," 35 $","Many types of fish are consumed as food in almost all regions of the world. Fish has been an important source of protein and other nutrients for humans since long time ago, as fish contains many important nutrients for the human body, including vitamins, minerals and essential fatty acids."));
        foods.add(new Foods(4,R.drawable.shawrma,"Shawarma","7 $","Shawarma is a type of Middle Eastern food that has its roots in the Levant and the Ottoman Empire, and it is a special grilled meat where the meat is grilled by heat and radiation resulting from the heat source, which can be an electric or gas source or from coal. Shawarma is sold in fast food restaurants."));
        foods.add(new Foods(5,R.drawable.kimchi,"Kimchi","21 $","Kimchi is a traditional and basic Korean food, which is hardly without a poor or rich table. It is a food similar to that of pickles for Arabs and is based on cabbage, a lot of garlic and hot red pepper. Camchi is a warm, traditional pickled food. The kimchi can be eaten as an appetizer or as a dish served with rice."));
        foods.add(new Foods(6,R.drawable.soup,"Chicken Noodle Soup","40 $","Chicken soup is one of the traditional dishes in many cultures around the world. Region or state: International cuisine. The main ingredients: chicken, noodles."));
        foods.add(new Foods(7,R.drawable.pizzahut,"Pizza Hut ","55 $","Pizza is a dish that has its origins in eastern Mediterranean countries such as Greece and Turkey, where they cooked a layer of dough on a hot stone and covered it with various types of ingredients such as meat and vegetables, then the Italian soldiers took it from them to transport it to Italy with the addition of tomato sauce and mozzarella cheese, then transport it Italian immigrants to America."));
        foods.add(new Foods(8,R.drawable.burgers,"Hamburger","20 $","Hamburger is an American food that is often considered a fast food and has spread rapidly all over the world until it became a globalization meal, consisting of a sandwich of meat or chicken in addition to ketchup, mayonnaise and vegetables, and eaten with it french fries and soft drinks such as Pepsi and Coca-Cola."));
        foods.add(new Foods(9,R.drawable.fish,"Fish"," 35 $","Many types of fish are consumed as food in almost all regions of the world. Fish has been an important source of protein and other nutrients for humans since long time ago, as fish contains many important nutrients for the human body, including vitamins, minerals and essential fatty acids."));
        foods.add(new Foods(10,R.drawable.shawrma,"Shawarma","7 $","Shawarma is a type of Middle Eastern food that has its roots in the Levant and the Ottoman Empire, and it is a special grilled meat where the meat is grilled by heat and radiation resulting from the heat source, which can be an electric or gas source or from coal. Shawarma is sold in fast food restaurants."));
        foods.add(new Foods(11,R.drawable.kimchi,"Kimchi","21 $","Kimchi is a traditional and basic Korean food, which is hardly without a poor or rich table. It is a food similar to that of pickles for Arabs and is based on cabbage, a lot of garlic and hot red pepper. Camchi is a warm, traditional pickled food. The kimchi can be eaten as an appetizer or as a dish served with rice."));
        foods.add(new Foods(12,R.drawable.soup,"Chicken Noodle Soup","21 $","Chicken soup is one of the traditional dishes in many cultures around the world. Region or state: International cuisine. The main ingredients: chicken, noodles."));

        FoodAdapter foodAdapter = new FoodAdapter(foods, getContext());


//        FoodAdapter foodAdapter = new FoodAdapter(foods, getContext(), new FoodAdapter.OnListViewItemClickListener() {
//            @Override
//            public void onItemClick(Foods food) {
//                Toast.makeText(getContext(), "id_food: " + food.getId(), Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent(getContext(), FoodDetialsActivity.class);
//                intent.putExtra("food_iv", food.getImage());
//                intent.putExtra("food_dec", food.getDesc());
//                startActivity(intent);
//            }
//        });
        lv_foods.setAdapter(foodAdapter);
        lv_foods.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Foods food = foods.get(position);

                Toast.makeText(getContext(), "id_food: " + food.getId(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getContext(), FoodDetialsActivity.class);
                intent.putExtra("food_iv", food.getImage());
                intent.putExtra("food_name", food.getName());
                intent.putExtra("food_price", food.getPrice());
                intent.putExtra("food_dec", food.getDesc());
                startActivity(intent);
            }
        });

//        lv_foods.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Foods dataModel = foods.get(position);
//
//                Snackbar.make(view, dataModel.getName() + "\n" + dataModel.getId() + " | " + dataModel.getName(), Snackbar.LENGTH_LONG)
//                        .setAction("No action", null).show();
//            }
//        });

        return root;
    }
}