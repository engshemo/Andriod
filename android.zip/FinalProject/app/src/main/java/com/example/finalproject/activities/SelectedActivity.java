package com.example.finalproject.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.finalproject.R;

import java.util.ArrayList;

public class SelectedActivity extends AppCompatActivity {
    ListView lv_selected;
    static ArrayList<String> listItems;
    ArrayAdapter<String> arrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected);
        lv_selected=findViewById(R.id.lv_selected);
//        arrayList = new ArrayList<>();
//        Intent intent = getIntent();
//        String item = intent.getStringExtra("food_name");
//        arrayList.add(item);
        ArrayList<String> listItems = new ArrayList<String>();
        listItems.add("LIST");
        arrayAdapter= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listItems);
        //this or getApplicationContext
        lv_selected.setAdapter(arrayAdapter);

    }
}