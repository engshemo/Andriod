package com.example.finalproject.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.example.finalproject.R;
import com.example.finalproject.fragments.DialogFragment;
import com.example.finalproject.ui.Food.FoodFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

public class MainActivity extends AppCompatActivity {
TextView tv_main;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
         tv_main = findViewById(R.id.tv_main);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_foods, R.id.navigation_desserts, R.id.navigation_drinks)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);
        tv_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                YoYo.with(Techniques.Wave)
                        .duration(700)
                        .repeat(5)
                        .playOn(findViewById(R.id.tv_main));
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){

            case R.id.login_item:
                Toast.makeText(getApplicationContext(), "You are logined", Toast.LENGTH_LONG).show();
                return true;
            case R.id.home_item:
                  Intent i = new Intent(getApplicationContext(),SelectedActivity.class);
                  startActivity(i);
                return true;
            case R.id.logout_item:
                DialogFragment fragment = DialogFragment.newInstance("Attention", "Do you really want to log out ?? ", R.drawable.ic_alert);
                fragment.show(getSupportFragmentManager(), null);
            case R.id.register_item:
                DialogFragment fragment1 = DialogFragment.newInstance("Attention", "Do you really want to log out ?? ", R.drawable.ic_alert);
                fragment1.show(getSupportFragmentManager(), null);
            default:
                return super.onOptionsItemSelected(item);

        }

    }

}