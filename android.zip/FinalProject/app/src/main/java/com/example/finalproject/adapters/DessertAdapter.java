package com.example.finalproject.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.example.finalproject.R;
import com.example.finalproject.models.Desserts;
import com.example.finalproject.models.Foods;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class DessertAdapter extends BaseAdapter {
    ArrayList<Desserts> desserts;
    Context context;
    LayoutInflater layoutInflater;

    public DessertAdapter(ArrayList<Desserts> desserts, Context context) {
        this.desserts = desserts;
        this.context = context;
        layoutInflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public int getCount() {
        return desserts.size();
    }

    @Override
    public Object getItem(int position) {
        return desserts.get(position);
    }

    @Override
    public long getItemId(int position) {
        return desserts.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View root = layoutInflater.inflate(R.layout.desert_item,null);
        CircleImageView dessert_image =root.findViewById(R.id.dessert_image);
        TextView dessert_name =root.findViewById(R.id.dessert_name);
        TextView dessert_price =root.findViewById(R.id.dessert_price);
        ConstraintLayout dessert_layout =root.findViewById(R.id.dessert_layout);
        dessert_image.setImageResource(desserts.get(position).getImage());
        dessert_name.setText(desserts.get(position).getName());
        dessert_price.setText(desserts.get(position).getPrice());
        final Desserts dessert = desserts.get(position);

//        dessert_layout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                YoYo.with(Techniques.Tada)
//                        .duration(700)
//                        .repeat(5)
//                        .playOn(root.findViewById(R.id.dessert_layout));
//            }
//        });
        return root;
    }
}
