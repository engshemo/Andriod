package com.example.finalproject.ui.Deserts;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.finalproject.R;
import com.example.finalproject.activities.DessertDetailsActivity;
import com.example.finalproject.activities.FoodDetialsActivity;
import com.example.finalproject.adapters.DessertAdapter;
import com.example.finalproject.adapters.DrinkAdapter;
import com.example.finalproject.models.Desserts;
import com.example.finalproject.models.Drinks;
import com.example.finalproject.models.Foods;

import java.util.ArrayList;

public class DesertsFragment extends Fragment {
    ArrayList<Desserts> desserts;
    DessertAdapter dessertAdapter;
   ListView lv_desserts;
   ConstraintLayout constraintLayout;
    private DashboardViewModel dashboardViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dashboardViewModel =
                new ViewModelProvider(this).get(DashboardViewModel.class);
        View root = inflater.inflate(R.layout.fragment_deserts, container, false);
        lv_desserts=root.findViewById(R.id.lv_desserts);
        desserts=new ArrayList<>();
        desserts.add(new Desserts(1,R.drawable.p1,"Frozen Yogurt","12 $","Frozen yogurt or frozen yogurt is a frozen dessert that contains yogurt or other dairy products. It is more tart and tart than ice cream, as well as less fat. It differs from frozen milk which does not include yogurt as an ingredient."));
        desserts.add(new Desserts(2,R.drawable.p2," Cupcake "," 15 $","Cupcakes, Cupcakes or Cupcakes A small cake designed to be served to one person, usually wrapped in small thin bags or in aluminum cups. As with cakes, decorate with cream and other decorations, such as sprinkles, are common on cakes."));
        desserts.add(new Desserts(3,R.drawable.p3," Sheesecake Brownies"," 18 $","These cheesecake brownies are a rich and fudgy chocolate brownie topped with a layer of sweetened cream cheese. A show stopping dessert that’s easy to make and always gets rave reviews!"));
        desserts.add(new Desserts(4,R.drawable.p4," Cheesecake "," 9 $","Cheesecake is a dessert originally from Greece. Urbanization in most parts of the world. Its ingredients can vary by country, but the most prepared American recipe remains. You can cover and decorate the cheesecake with different types of fruits, such as strawberries or berries and others."));
        desserts.add(new Desserts(5,R.drawable.p5," Cake pop "," 21 $","Cake pop is a form of lollipop cake. Prepared by mixing cake crumbs with icing or chocolate. Then the mixture is formed in the form of balls or small cubes, before being covered with a layer of sugar coverage, chocolate or any other decoration and then attached to the lollipop stick. A cake pop can be a way to use up cake leftovers or crumbs."));
        desserts.add(new Desserts(6,R.drawable.moltencake," Molten chocolate cake "," 10 $","Cake made with eggs, sugar, flour, butter and chocolate. Contains a high number of calories, each bar contains 483 calories, 276 mg of cholesterol and 20 g of saturated fat."));
        desserts.add(new Desserts(7,R.drawable.doghnuts," Doghnuts "," 3 $","Mabroumeh, donuts, fried cake, or sweet ring cake is a type of pastry that is fried in oil and sweetened with jam, jelly, cream, starch or any other sweetener. It usually takes the hollow or solid circular shape."));
        desserts.add(new Desserts(8,R.drawable.p6," Choco pie "," 8 $","Choco cake is a light cake made of two small round layers of cake with marshmallow filling and chocolate coating. The term originated in America but is now also used widely in South Korea, Japan and their exports, and many other countries as a brand or generic name."));
        desserts.add(new Desserts(1,R.drawable.p1,"Frozen Yogurt","12 $","Frozen yogurt or frozen yogurt is a frozen dessert that contains yogurt or other dairy products. It is more tart and tart than ice cream, as well as less fat. It differs from frozen milk which does not include yogurt as an ingredient."));
        desserts.add(new Desserts(2,R.drawable.p2," Cupcake "," 15 $","Cupcakes, Cupcakes or Cupcakes A small cake designed to be served to one person, usually wrapped in small thin bags or in aluminum cups. As with cakes, decorate with cream and other decorations, such as sprinkles, are common on cakes."));
        desserts.add(new Desserts(3,R.drawable.p3," Sheesecake Brownies"," 18 $","These cheesecake brownies are a rich and fudgy chocolate brownie topped with a layer of sweetened cream cheese. A show stopping dessert that’s easy to make and always gets rave reviews!"));
        desserts.add(new Desserts(4,R.drawable.p4," Cheesecake "," 9 $","Cheesecake is a dessert originally from Greece. Urbanization in most parts of the world. Its ingredients can vary by country, but the most prepared American recipe remains. You can cover and decorate the cheesecake with different types of fruits, such as strawberries or berries and others."));
        desserts.add(new Desserts(5,R.drawable.p5," Cake pop "," 21 $","Cake pop is a form of lollipop cake. Prepared by mixing cake crumbs with icing or chocolate. Then the mixture is formed in the form of balls or small cubes, before being covered with a layer of sugar coverage, chocolate or any other decoration and then attached to the lollipop stick. A cake pop can be a way to use up cake leftovers or crumbs."));
        desserts.add(new Desserts(6,R.drawable.moltencake," Molten chocolate cake "," 10 $","Cake made with eggs, sugar, flour, butter and chocolate. Contains a high number of calories, each bar contains 483 calories, 276 mg of cholesterol and 20 g of saturated fat."));
        desserts.add(new Desserts(7,R.drawable.doghnuts," Doghnuts "," 3 $","Mabroumeh, donuts, fried cake, or sweet ring cake is a type of pastry that is fried in oil and sweetened with jam, jelly, cream, starch or any other sweetener. It usually takes the hollow or solid circular shape."));
        desserts.add(new Desserts(8,R.drawable.p6," Choco pie "," 8 $","Choco cake is a light cake made of two small round layers of cake with marshmallow filling and chocolate coating. The term originated in America but is now also used widely in South Korea, Japan and their exports, and many other countries as a brand or generic name."));



        dessertAdapter=new DessertAdapter(desserts,getContext());
        lv_desserts.setAdapter(dessertAdapter);
        lv_desserts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Desserts dessert = desserts.get(position);

                Toast.makeText(getContext(), "id_dessert: " + dessert.getId(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getContext(), DessertDetailsActivity.class);
                intent.putExtra("dessert_iv", dessert.getImage());
                intent.putExtra("dessert_name", dessert.getName());
                intent.putExtra("dessert_price", dessert.getPrice());
                intent.putExtra("dessert_dec", dessert.getDesc());
                startActivity(intent);
            }
        });



        return root;
    }
}