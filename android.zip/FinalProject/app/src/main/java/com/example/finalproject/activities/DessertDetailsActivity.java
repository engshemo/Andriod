package com.example.finalproject.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.example.finalproject.R;
import com.example.finalproject.fragments.DialogFragment;

import de.hdodenhof.circleimageview.CircleImageView;

public class DessertDetailsActivity extends AppCompatActivity {
    CircleImageView iv_dessert_image;
    TextView tv_dessert_name,tv_dessert_price,tv_dessert_desc;
    Button btu_dessert_select;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dessert_details);
        this.setTitle("Dessert Details Page .");
        this.setTitleColor(R.color.orange);
        iv_dessert_image = findViewById(R.id.iv_dessert_image);
        tv_dessert_desc = findViewById(R.id.tv_dessert_desc);
        tv_dessert_name = findViewById(R.id.tv_dessert_name);
        tv_dessert_price = findViewById(R.id.tv_dessert_price);
        btu_dessert_select = findViewById(R.id.btu_dessert_select);
        Intent intent = getIntent();
        int dessert_iv = intent.getIntExtra("dessert_iv", 1);
        String dessert_name = intent.getStringExtra("dessert_name");
        String dessert_price = intent.getStringExtra("dessert_price");
        String dessert_dec = intent.getStringExtra("dessert_dec");
        btu_dessert_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogFragment fragment = DialogFragment.newInstance("Attention", " Do you really want this dessert ? ", R.drawable.ic_alert);
                fragment.show(getSupportFragmentManager(), null);
            }
        });
        YoYo.with(Techniques.BounceInRight)
                .duration(700)
                .repeat(3)
                .playOn(findViewById(R.id.iv_dessert_image));
        YoYo.with(Techniques.BounceInRight)
                .duration(700)
                .repeat(2)
                .playOn(findViewById(R.id.tv_dessert_desc));
        YoYo.with(Techniques.BounceInRight)
                .duration(700)
                .repeat(2)
                .playOn(findViewById(R.id.tv_dessert_name));
        YoYo.with(Techniques.BounceInRight)
                .duration(700)
                .repeat(2)
                .playOn(findViewById(R.id.tv_dessert_price));

        if (dessert_iv != 0) {
            iv_dessert_image.setImageResource(dessert_iv);
        }
        if (dessert_dec != null) {
            tv_dessert_desc.setText(dessert_dec);
        }
        if (dessert_price != null) {
            tv_dessert_price.setText(dessert_price);
        }
        if (dessert_name != null) {
            tv_dessert_name.setText(dessert_name);
        }

    }
}