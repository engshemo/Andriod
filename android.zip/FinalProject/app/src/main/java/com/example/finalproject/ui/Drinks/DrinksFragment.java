package com.example.finalproject.ui.Drinks;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.finalproject.R;
import com.example.finalproject.activities.DessertDetailsActivity;
import com.example.finalproject.activities.DrinkDetailsActivity;
import com.example.finalproject.adapters.DrinkAdapter;
import com.example.finalproject.models.Desserts;
import com.example.finalproject.models.Drinks;

import java.util.ArrayList;

public class DrinksFragment extends Fragment {
    ArrayList<Drinks> drinks;
    DrinkAdapter drinkAdapter;
    GridView gv_drinks;
    private NotificationsViewModel notificationsViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        notificationsViewModel =
                new ViewModelProvider(this).get(NotificationsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_drinks, container, false);
        gv_drinks=root.findViewById(R.id.gv_drinks);
        drinks=new ArrayList<>();
        drinks.add(new Drinks(1,R.drawable.coffee,"Coffee","6 $","Coffee is a drink made from roasted coffee seeds, and is grown in more than 70 countries. Especially in the tropics of North and South America, Southeast Asia, the Indian subcontinent and Africa. Green coffee is said to be the second most traded commodity in the world, after crude oil. Due to its caffeine content, coffee can have a stimulating effect in humans."));
        drinks.add(new Drinks(2,R.drawable.tea,"Tea","5 $","Tea is the Chinese name given to a tree or shrub, its leaves, and the drink that is made from the leaves, and its evergreen plant. It is attributed to the Chinese camellia plant, and it is native to eastern Asia. In its habitat it grows to a height of 9 meters, but in the farms it prunes small bushes 90- 150 cm in length. Its lanceolate leaves are dark green, and the flowers are yellowish-white fragrant."));
        drinks.add(new Drinks(3,R.drawable.cola,"Cola","7 $","Cola is a soft drink that contains sugar, caramel colors, as well as caffeine, such as Coca-Cola, Pepsi-Cola, Sea-Cola, Mecca-Cola and Cinalco-Cola. The cola drink was invented by the chemist John Pembert using the extract of the kola nut, and it quickly spread around the world and the cola drink became a slogan denoting the United States"));
        drinks.add(new Drinks(4,R.drawable.niscaffe,"Niscaffe","8 $","Nescafe is a coffee brand made by Nestlé. It comes in many different forms. The name is a bearer of the words Nestlé and Cafe ."));
        drinks.add(new Drinks(5,R.drawable.cappuccino,"Capuino","5 $","Cappuccino is a type of coffee mixed with milk, and it was invented by the Italians. It is found in coffee shops and cafes and is decorated with types of decorations such as foam or cream. Italian coffee made of espresso in small quantities, to which milk and milk foam are added equally."));
        drinks.add(new Drinks(1,R.drawable.coffee,"Coffee","6 $","Coffee is a drink made from roasted coffee seeds, and is grown in more than 70 countries. Especially in the tropics of North and South America, Southeast Asia, the Indian subcontinent and Africa. Green coffee is said to be the second most traded commodity in the world, after crude oil. Due to its caffeine content, coffee can have a stimulating effect in humans."));
        drinks.add(new Drinks(2,R.drawable.tea,"Tea","5 $","Tea is the Chinese name given to a tree or shrub, its leaves, and the drink that is made from the leaves, and its evergreen plant. It is attributed to the Chinese camellia plant, and it is native to eastern Asia. In its habitat it grows to a height of 9 meters, but in the farms it prunes small bushes 90- 150 cm in length. Its lanceolate leaves are dark green, and the flowers are yellowish-white fragrant."));
        drinks.add(new Drinks(3,R.drawable.cola,"Cola","7 $","Cola is a soft drink that contains sugar, caramel colors, as well as caffeine, such as Coca-Cola, Pepsi-Cola, Sea-Cola, Mecca-Cola and Cinalco-Cola. The cola drink was invented by the chemist John Pembert using the extract of the kola nut, and it quickly spread around the world and the cola drink became a slogan denoting the United States"));
        drinks.add(new Drinks(4,R.drawable.niscaffe,"Niscaffe","8 $","Nescafe is a coffee brand made by Nestlé. It comes in many different forms. The name is a bearer of the words Nestlé and Cafe ."));
        drinks.add(new Drinks(5,R.drawable.cappuccino,"Capuino","5 $","Cappuccino is a type of coffee mixed with milk, and it was invented by the Italians. It is found in coffee shops and cafes and is decorated with types of decorations such as foam or cream. Italian coffee made of espresso in small quantities, to which milk and milk foam are added equally."));
        drinks.add(new Drinks(1,R.drawable.coffee,"Coffee","6 $","Coffee is a drink made from roasted coffee seeds, and is grown in more than 70 countries. Especially in the tropics of North and South America, Southeast Asia, the Indian subcontinent and Africa. Green coffee is said to be the second most traded commodity in the world, after crude oil. Due to its caffeine content, coffee can have a stimulating effect in humans."));
        drinks.add(new Drinks(2,R.drawable.tea,"Tea","5 $","Tea is the Chinese name given to a tree or shrub, its leaves, and the drink that is made from the leaves, and its evergreen plant. It is attributed to the Chinese camellia plant, and it is native to eastern Asia. In its habitat it grows to a height of 9 meters, but in the farms it prunes small bushes 90- 150 cm in length. Its lanceolate leaves are dark green, and the flowers are yellowish-white fragrant."));
        drinks.add(new Drinks(3,R.drawable.cola,"Cola","7 $","Cola is a soft drink that contains sugar, caramel colors, as well as caffeine, such as Coca-Cola, Pepsi-Cola, Sea-Cola, Mecca-Cola and Cinalco-Cola. The cola drink was invented by the chemist John Pembert using the extract of the kola nut, and it quickly spread around the world and the cola drink became a slogan denoting the United States"));
        drinks.add(new Drinks(4,R.drawable.niscaffe,"Niscaffe","8 $","Nescafe is a coffee brand made by Nestlé. It comes in many different forms. The name is a bearer of the words Nestlé and Cafe ."));
        drinks.add(new Drinks(5,R.drawable.cappuccino,"Capuino","5 $","Cappuccino is a type of coffee mixed with milk, and it was invented by the Italians. It is found in coffee shops and cafes and is decorated with types of decorations such as foam or cream. Italian coffee made of espresso in small quantities, to which milk and milk foam are added equally."));

        drinkAdapter=new DrinkAdapter(drinks,getContext());
        gv_drinks.setAdapter(drinkAdapter);
        gv_drinks.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Drinks drink = drinks.get(position);

                Toast.makeText(getContext(), "id_drink: " + drink.getId(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getContext(), DrinkDetailsActivity.class);
                intent.putExtra("drink_iv", drink.getImage());
                intent.putExtra("drink_name", drink.getName());
                intent.putExtra("drink_price", drink.getPrice());
                intent.putExtra("drink_dec", drink.getDesc());
                startActivity(intent);
            }
        });
        return root;
    }
}