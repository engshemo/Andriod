package com.example.finalproject.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.example.finalproject.R;
import com.example.finalproject.fragments.DialogFragment;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class FoodDetialsActivity extends AppCompatActivity {
Button btu_food_select;
    CircleImageView iv_food_image;
    TextView tv_food_name,tv_food_price,tv_food_desc;
    ArrayList<String> arrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_detials);
        this.setTitle("Food Details Page .");
        arrayList = new ArrayList<>();
        iv_food_image = findViewById(R.id.iv_food_image);
    tv_food_desc = findViewById(R.id.tv_food_desc);
    tv_food_name = findViewById(R.id.tv_food_name);
    tv_food_price = findViewById(R.id.tv_food_price);
    btu_food_select = findViewById(R.id.btu_food_select);
    Intent intent = getIntent();
    int food_iv = intent.getIntExtra("food_iv", 1);
    String food_name = intent.getStringExtra("food_name");
    String food_price = intent.getStringExtra("food_price");
    String food_dec = intent.getStringExtra("food_dec");

    btu_food_select.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
//            DialogFragment fragment = DialogFragment.newInstance("Attention", "Do you really want this food? ", R.drawable.ic_alert);
//            fragment.show(getSupportFragmentManager(), null);
            Intent intent = new Intent(getApplicationContext(), SelectedActivity.class);
            intent.putExtra("food_name", food_name);
            startActivity(intent);


        }
    });
        YoYo.with(Techniques.BounceInRight)
                .duration(700)
                .repeat(3)
                .playOn(findViewById(R.id.iv_food_image));
        YoYo.with(Techniques.BounceInRight)
                .duration(700)
                .repeat(2)
                .playOn(findViewById(R.id.tv_food_desc));
        YoYo.with(Techniques.BounceInRight)
                .duration(700)
                .repeat(2)
                .playOn(findViewById(R.id.tv_food_name));
        YoYo.with(Techniques.BounceInRight)
                .duration(700)
                .repeat(2)
                .playOn(findViewById(R.id.tv_food_price));

        if (food_iv != 0) {
        iv_food_image.setImageResource(food_iv);
    }
        if (food_dec != null) {
        tv_food_desc.setText(food_dec);
    }
        if (food_price != null) {
        tv_food_price.setText(food_price);
    }
        if (food_name != null) {
        tv_food_name.setText(food_name);
    }

}
}