package com.example.finalproject.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.example.finalproject.R;
import com.example.finalproject.models.Desserts;
import com.example.finalproject.models.Foods;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class FoodAdapter extends BaseAdapter {
    private ArrayList<Foods> foods;
   private Context context;
   //private OnListViewItemClickListener listener;
   LayoutInflater layoutInflater;

    public FoodAdapter(ArrayList<Foods> foods, Context context) {
        this.foods = foods;
        this.context = context;
        layoutInflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }
//    public FoodAdapter(ArrayList<Foods> foods, Context context, OnListViewItemClickListener listener) {
//        this.foods = foods;
//        this.context = context;
//        this.listener = listener;
//    }

    @Override
    public int getCount() {
        return foods.size();
    }

    @Override
    public Object getItem(int position) {
        return foods.get(position);
    }

    @Override
    public long getItemId(int position) {
        return foods.get(position).getId();
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        View root = view;
        if (root == null) {
            root = LayoutInflater.from(context).inflate(R.layout.food_item, viewGroup, false);
        }


        // inflate to items
        CircleImageView food_image =root.findViewById(R.id.food_image);
        TextView food_name =root.findViewById(R.id.food_name);
        TextView food_price =root.findViewById(R.id.food_price);
        ConstraintLayout food_layout =root.findViewById(R.id.food_layout);

        //جلب البيانات
        food_image.setImageResource(foods.get(position).getImage());
        food_name.setText(foods.get(position).getName());
        food_price.setText(foods.get(position).getPrice());

        final Foods food = foods.get(position);
//        root.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                listener.onItemClick(food);
//            }
//        });

        return root;




//        View root = layoutInflater.inflate(R.layout.food_item,null);
//        CircleImageView food_image =root.findViewById(R.id.food_image);
//        TextView food_name =root.findViewById(R.id.food_name);
//        TextView food_price =root.findViewById(R.id.food_price);
//        ConstraintLayout food_layout =root.findViewById(R.id.food_layout);
//        food_image.setImageResource(foods.get(position).getImage());
//        food_name.setText(foods.get(position).getName());
//        food_price.setText(foods.get(position).getPrice());
//        food_layout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                YoYo.with(Techniques.Tada)
//                        .duration(700)
//                        .repeat(5)
//                        .playOn(root.findViewById(R.id.food_layout));
//            }
//        });
//        return root;
    }

//    public interface OnListViewItemClickListener {
//        void onItemClick(Foods food);
//    }

}
